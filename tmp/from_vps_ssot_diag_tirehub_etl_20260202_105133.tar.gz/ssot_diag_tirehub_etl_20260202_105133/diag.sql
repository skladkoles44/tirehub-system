\pset format unaligned
\pset tuples_only on
\pset pager off
SET statement_timeout='15s';
SET lock_timeout='3s';

SELECT 'meta|ts|'||to_char(now(),'YYYY-MM-DD HH24:MI:SS');
SELECT 'meta|db|'||current_database();
SELECT 'meta|user|'||current_user;
SELECT 'meta|server|'||version();

-- schemas
SELECT 'schema|exists|'||n.nspname||'|true'
FROM pg_namespace n
WHERE n.nspname LIKE 'ssot_%'
ORDER BY n.nspname;

-- relations (tables/views/mviews/sequences)
SELECT 'rel|'||n.nspname||'.'||c.relname||'|kind='||c.relkind||'|rows_est='||COALESCE(c.reltuples::text,'?')
FROM pg_class c
JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE n.nspname LIKE 'ssot_%'
  AND c.relkind IN ('r','v','m','S')  -- r=table, v=view, m=matview, S=sequence
ORDER BY n.nspname, c.relkind, c.relname;

-- constraints
SELECT 'constraint|'||cn.nspname||'.'||cl.relname||'|'||co.conname||'|'||pg_get_constraintdef(co.oid)
FROM pg_constraint co
JOIN pg_class cl ON cl.oid=co.conrelid
JOIN pg_namespace cn ON cn.oid=cl.relnamespace
WHERE cn.nspname LIKE 'ssot_%'
ORDER BY cn.nspname, cl.relname, co.conname;

-- indexes
SELECT 'index|'||schemaname||'.'||tablename||'|'||indexname||'|'||indexdef
FROM pg_indexes
WHERE schemaname LIKE 'ssot_%'
ORDER BY schemaname, tablename, indexname;

-- functions (signatures only + short header)
SELECT 'func|'||n.nspname||'.'||p.proname||'|'||pg_get_function_identity_arguments(p.oid)
FROM pg_proc p
JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname LIKE 'ssot_%'
ORDER BY n.nspname, p.proname, pg_get_function_identity_arguments(p.oid);
